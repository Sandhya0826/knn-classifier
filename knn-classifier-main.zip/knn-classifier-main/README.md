# knn-classifier
A classification problem using K-Nearest Neighbour algorithm 
